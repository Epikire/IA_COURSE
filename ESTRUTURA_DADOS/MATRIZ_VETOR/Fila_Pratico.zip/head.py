# EXERCICIO 3 - HEAD

fila_mercado = ["Pedro", "Lucas", "Mariana"]

proximo_cliente = fila_mercado[0]

print(f"Próximo cliente a ser atendido: {proximo_cliente}")

