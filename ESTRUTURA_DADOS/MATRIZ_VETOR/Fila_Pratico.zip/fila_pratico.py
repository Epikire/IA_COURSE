# EXERCICIO 1 - ENQUEUE

fila = ["João", "Maria", "José"]
print(f"Fila inicial: {fila}")

novo_cliente = "Ana"
fila.append(novo_cliente)

print(f"Fila após a chegada de Ana: {fila}")


# EXERCICIO 2 - SIZE

fila_banco = ["Cliente1", "Cliente2", "Cliente3", "Cliente4"]

tamanho_fila = len(fila_banco)

print(f"Quantidade de clientes aguardando: {tamanho_fila}")
