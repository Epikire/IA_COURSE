# EXERCICIO 5 = EMPTY

fila_sala_espera = []

if len(fila_sala_espera) == 0:
    print(f"A sala de espera está vazia.")

else:
    print("Ainda há pacientes aguardando.")

