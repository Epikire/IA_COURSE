# EXERCICIO 4 - DEQUEUE

fila_consultorio = ["Paciente1", "Paciente2", "Paciente3"]
print(f"Fila antes do atendimento: {fila_consultorio}")

paciente_atendido = fila_consultorio.pop(0)

print(f"Paciente atendido: {paciente_atendido}")
print(f"Fila após atendimento: {fila_consultorio}")

